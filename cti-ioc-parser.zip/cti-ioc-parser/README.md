# CTI IOC Parser

A simple Python tool to extract, refang and classify Indicators of Compromise (IOCs) from threat intelligence reports, incident notes, emails or raw text files.

This project is designed as a practical Cyber Threat Intelligence portfolio project.

## What it does

The parser detects and classifies:

- IPv4 addresses
- Domains
- URLs
- Email addresses
- MD5 hashes
- SHA1 hashes
- SHA256 hashes

It also converts common defanged indicators into usable indicators.

Example:

```text
hxxps://evil-domain[.]com/payload.exe
185[.]220[.]101[.]45
```

Becomes:

```text
https://evil-domain.com/payload.exe
185.220.101.45
```

## Why this matters in CTI

Threat Intelligence analysts often work with reports, feeds, malware write-ups, phishing emails and incident notes. Extracting IOCs manually is slow and error-prone.

This tool helps automate the first step of the CTI workflow:

1. Collect raw intelligence
2. Extract indicators
3. Normalize the indicators
4. Export them for enrichment, SIEM hunting or further analysis

## Installation

Clone the repository:

```bash
git clone https://github.com/YOUR-USERNAME/cti-ioc-parser.git
cd cti-ioc-parser
```

No external dependencies are required for the basic version.

## Usage

Run the parser against a text file:

```bash
python src/cti_ioc_parser/parser.py examples/sample_report.txt
```

Export results to JSON:

```bash
python src/cti_ioc_parser/parser.py examples/sample_report.txt --json outputs/iocs.json
```

Export results to CSV:

```bash
python src/cti_ioc_parser/parser.py examples/sample_report.txt --csv outputs/iocs.csv
```

Export both formats:

```bash
python src/cti_ioc_parser/parser.py examples/sample_report.txt --json outputs/iocs.json --csv outputs/iocs.csv
```

## Example output

```json
{
    "ipv4": [
        "185.220.101.45"
    ],
    "domain": [
        "backup-c2.net"
    ],
    "url": [
        "https://evil-domain.com/payload.exe"
    ],
    "email": [
        "support@fake-microsoft-alert.com"
    ],
    "md5": [
        "44d88612fea8a8f36de82e1278abb02f"
    ],
    "sha1": [
        "3395856ce81f2b7382dee72602f798b642f14140"
    ],
    "sha256": [
        "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    ]
}
```

## Suggested next improvements

This basic version can be expanded with:

- VirusTotal enrichment
- AbuseIPDB enrichment
- WHOIS lookups
- ASN and geolocation lookup
- STIX/TAXII export
- MISP integration
- OpenCTI integration
- Sigma rule generation
- Splunk lookup export

## Portfolio positioning

This project shows practical skills in:

- Cyber Threat Intelligence
- IOC handling
- Python scripting
- Automation
- Threat analysis workflows
- Defensive security operations

It is especially useful for junior profiles aiming for roles such as:

- CTI Analyst
- SOC Analyst
- Threat Hunter Junior
- Blue Team Analyst
- Cyber Intelligence Analyst

## Disclaimer

This tool is for educational and defensive security purposes only.
