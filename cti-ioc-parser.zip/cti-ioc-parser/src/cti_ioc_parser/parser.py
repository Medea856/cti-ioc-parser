import re
import json
import csv
import argparse
from pathlib import Path
from typing import Dict, List, Set


IOC_PATTERNS = {
    "ipv4": r"\b(?:(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]?\d)\b",
    "domain": r"\b(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}\b",
    "url": r"\b(?:https?|hxxps?|ftp)://[^\s\"'<>]+",
    "email": r"\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b",
    "md5": r"\b[a-fA-F0-9]{32}\b",
    "sha1": r"\b[a-fA-F0-9]{40}\b",
    "sha256": r"\b[a-fA-F0-9]{64}\b",
}


def refang(text: str) -> str:
    """Convert defanged IOCs into usable indicators."""
    replacements = {
        "hxxps://": "https://",
        "hxxp://": "http://",
        "[.]": ".",
        "(.)": ".",
        "{.}": ".",
        "[://]": "://",
    }
    cleaned = text
    for old, new in replacements.items():
        cleaned = cleaned.replace(old, new)
    return cleaned


def extract_iocs(text: str) -> Dict[str, List[str]]:
    """Extract and classify IOCs from raw text."""
    cleaned_text = refang(text)
    results: Dict[str, Set[str]] = {key: set() for key in IOC_PATTERNS}

    for ioc_type, pattern in IOC_PATTERNS.items():
        matches = re.findall(pattern, cleaned_text)
        for match in matches:
            results[ioc_type].add(match.strip().rstrip(".,;:)"))

    # Avoid duplicating domains already contained inside URLs or emails.
    url_text = " ".join(results["url"])
    email_text = " ".join(results["email"])
    filtered_domains = {
        domain for domain in results["domain"]
        if domain not in url_text and domain not in email_text
    }
    results["domain"] = filtered_domains

    return {key: sorted(value) for key, value in results.items() if value}


def export_json(iocs: Dict[str, List[str]], output_path: Path) -> None:
    output_path.write_text(json.dumps(iocs, indent=4), encoding="utf-8")


def export_csv(iocs: Dict[str, List[str]], output_path: Path) -> None:
    with output_path.open("w", newline="", encoding="utf-8") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(["ioc_type", "value"])
        for ioc_type, values in iocs.items():
            for value in values:
                writer.writerow([ioc_type, value])


def main() -> None:
    parser = argparse.ArgumentParser(description="Extract IOCs from text files for CTI analysis.")
    parser.add_argument("input", help="Path to the input text file")
    parser.add_argument("--json", dest="json_output", help="Path to save JSON output")
    parser.add_argument("--csv", dest="csv_output", help="Path to save CSV output")
    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    text = input_path.read_text(encoding="utf-8")
    iocs = extract_iocs(text)

    print(json.dumps(iocs, indent=4))

    if args.json_output:
        export_json(iocs, Path(args.json_output))
    if args.csv_output:
        export_csv(iocs, Path(args.csv_output))


if __name__ == "__main__":
    main()
