# Changelog

## v1.0.0

Initial professional release.

### Added
- IOC extraction from raw text files.
- Refang support for common defanged indicators.
- IPv4, URL, domain, email, MD5, SHA1 and SHA256 extraction.
- JSON and CSV export.
- Sample threat intelligence reports.
- FastAPI endpoint for IOC extraction.
- Streamlit dashboard prototype.
- Dockerfile.
- Pytest test suite.
- MIT License.
