"""
FastAPI wrapper for CTI IOC Parser.

Run:
    uvicorn api.main:app --reload
"""

from fastapi import FastAPI
from pydantic import BaseModel

from parser import extract_iocs


app = FastAPI(
    title="CTI IOC Parser API",
    description="API to extract and normalize Indicators of Compromise from raw text.",
    version="1.0.0",
)


class ParseRequest(BaseModel):
    text: str


@app.get("/")
def health_check():
    return {"status": "ok", "service": "cti-ioc-parser-api"}


@app.post("/parse")
def parse_iocs(request: ParseRequest):
    return extract_iocs(request.text)
