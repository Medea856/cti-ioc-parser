"""
Simple Streamlit dashboard for CTI IOC Parser.

Run:
    streamlit run dashboard/app.py
"""

import json
import sys
from pathlib import Path

import streamlit as st

# Allow importing parser.py from project root
sys.path.append(str(Path(__file__).resolve().parents[1]))

from parser import extract_iocs


st.set_page_config(page_title="CTI IOC Parser", layout="wide")

st.title("CTI IOC Parser Dashboard")
st.write("Paste threat intelligence text, logs or reports to extract Indicators of Compromise.")

text = st.text_area("Input text", height=250)

if st.button("Extract IOCs"):
    if not text.strip():
        st.warning("Please paste some text first.")
    else:
        results = extract_iocs(text)

        col1, col2, col3 = st.columns(3)
        col1.metric("IPs", len(results["ips"]))
        col2.metric("URLs", len(results["urls"]))
        col3.metric("Domains", len(results["domains"]))

        st.subheader("Extracted IOCs")
        st.json(results)

        st.download_button(
            "Download JSON",
            data=json.dumps(results, indent=4),
            file_name="iocs.json",
            mime="application/json",
        )
