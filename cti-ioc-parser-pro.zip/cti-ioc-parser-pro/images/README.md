# Images

Add screenshots here, for example:

- terminal_demo.png
- dashboard_demo.png
- api_demo.png

Then reference them in the main README:

```markdown
![Terminal Demo](images/terminal_demo.png)
```
