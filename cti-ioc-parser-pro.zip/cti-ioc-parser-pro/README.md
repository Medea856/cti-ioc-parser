# CTI IOC Parser

Python-based tool designed to extract, normalize and export Indicators of Compromise from threat intelligence reports, logs, emails and raw text.

This project is built as a Cyber Threat Intelligence portfolio project focused on practical CTI, Blue Team automation and SOC workflows.

---

## Main Features

- Extracts common Indicators of Compromise:
  - IPv4 addresses
  - URLs
  - Domains
  - Emails
  - MD5 hashes
  - SHA1 hashes
  - SHA256 hashes

- Normalizes defanged IOCs:
  - `hxxp://` to `http://`
  - `hxxps://` to `https://`
  - `[.]` to `.`

- Exports results to:
  - JSON
  - CSV

- Includes:
  - Sample threat intelligence reports
  - FastAPI API endpoint
  - Streamlit dashboard prototype
  - Dockerfile
  - Pytest tests
  - Documentation
  - Roadmap

---

## Why This Project Matters

CTI analysts often work with reports, advisories, logs and threat feeds that contain large amounts of unstructured data.

This tool helps automate the first step of the intelligence workflow:

1. Extract indicators.
2. Normalize them.
3. Classify them.
4. Export them.
5. Use them for enrichment, threat hunting or SIEM correlation.

This is especially useful for:

- Cyber Threat Intelligence
- SOC investigations
- Threat Hunting
- Detection Engineering
- Incident Response
- OSINT workflows

---

## Project Structure

```text
cti-ioc-parser/
│
├── api/
│   └── main.py
│
├── dashboard/
│   └── app.py
│
├── docs/
│   ├── usage.md
│   ├── roadmap.md
│   └── mitre_attack_context.md
│
├── samples/
│   ├── phishing_campaign.txt
│   ├── ransomware_report.txt
│   └── stealer_iocs.txt
│
├── tests/
│   └── test_parser.py
│
├── parser.py
├── requirements.txt
├── Dockerfile
├── CHANGELOG.md
├── LICENSE
├── .gitignore
└── README.md
```

---

## Installation

Clone the repository:

```bash
git clone https://github.com/YOUR-USERNAME/cti-ioc-parser.git
cd cti-ioc-parser
```

Install dependencies:

```bash
pip install -r requirements.txt
```

---

## Basic Usage

Run the parser against a sample file:

```bash
python parser.py samples/ransomware_report.txt
```

By default, the tool creates:

```text
outputs/output.json
outputs/output.csv
```

You can also choose custom output paths:

```bash
python parser.py samples/phishing_campaign.txt --json outputs/phishing.json --csv outputs/phishing.csv
```

---

## Example Input

```text
The attacker connected to 185[.]220[.]101[.]45
and downloaded malware from hxxps://evil-domain[.]com/payload.exe
MD5: 44d88612fea8a8f36de82e1278abb02f
```

---

## Example Output

```json
{
    "ips": [
        "185.220.101.45"
    ],
    "urls": [
        "https://evil-domain.com/payload.exe"
    ],
    "domains": [
        "evil-domain.com"
    ],
    "emails": [],
    "md5": [
        "44d88612fea8a8f36de82e1278abb02f"
    ],
    "sha1": [],
    "sha256": []
}
```

---

## Run the API

Start the FastAPI server:

```bash
uvicorn api.main:app --reload
```

Health check:

```text
GET /
```

Parse text:

```text
POST /parse
```

Example request:

```json
{
    "text": "Payload hosted at hxxps://evil-domain[.]com/payload.exe"
}
```

---

## Run the Dashboard

Start the Streamlit dashboard:

```bash
streamlit run dashboard/app.py
```

The dashboard allows you to paste raw CTI text and extract IOCs visually.

---

## Run with Docker

Build the image:

```bash
docker build -t cti-ioc-parser .
```

Run the parser:

```bash
docker run cti-ioc-parser
```

---

## Run Tests

```bash
pytest
```

---

## Skills Demonstrated

This project demonstrates practical skills in:

- Cyber Threat Intelligence
- IOC extraction
- IOC normalization
- Python automation
- Regex parsing
- Blue Team workflows
- SOC support tooling
- API development
- Docker
- Testing with pytest
- Basic dashboarding

---

## Future Improvements

Planned improvements include:

- PDF report parsing
- VirusTotal enrichment
- MISP integration
- OpenCTI integration
- STIX/TAXII export
- ASN lookup
- WHOIS enrichment
- Splunk lookup export
- MITRE ATT&CK mapping
- Threat feed correlation

See [`docs/roadmap.md`](docs/roadmap.md) for more details.

---

## Suggested GitHub Topics

```text
cti
threat-intelligence
ioc
blue-team
cybersecurity
soc
osint
mitre-attack
python
threat-hunting
incident-response
```

---

## Disclaimer

This project is intended for educational purposes, research and defensive cybersecurity operations only.

Do not use this tool for unauthorized activity.

---

## Author

Cybersecurity & Threat Intelligence Portfolio Project
