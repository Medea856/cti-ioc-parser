#!/usr/bin/env python3
"""
CTI IOC Parser

A lightweight Cyber Threat Intelligence tool to extract, normalize and export
Indicators of Compromise from raw text, logs and threat intelligence reports.

Supported IOC types:
- IPv4 addresses
- URLs
- Domains
- Emails
- MD5, SHA1 and SHA256 hashes

Author: Cybersecurity & Threat Intelligence Portfolio Project
"""

import argparse
import csv
import json
import re
from pathlib import Path
from typing import Dict, List, Set


IOCResult = Dict[str, List[str]]


def refang(text: str) -> str:
    """
    Convert defanged indicators into usable indicators.

    Examples:
    - hxxp://example[.]com -> http://example.com
    - 185[.]220[.]101[.]45 -> 185.220.101.45
    """
    replacements = {
        "hxxps://": "https://",
        "hxxp://": "http://",
        "[.]": ".",
        "(.)": ".",
        "{.}": ".",
        "[:]": ":",
        "[://]": "://",
    }

    normalized = text
    for old, new in replacements.items():
        normalized = normalized.replace(old, new)

    return normalized


def extract_hashes(text: str) -> Dict[str, Set[str]]:
    md5 = set(re.findall(r"\b[a-fA-F0-9]{32}\b", text))
    sha1 = set(re.findall(r"\b[a-fA-F0-9]{40}\b", text))
    sha256 = set(re.findall(r"\b[a-fA-F0-9]{64}\b", text))

    return {
        "md5": md5,
        "sha1": sha1,
        "sha256": sha256,
    }


def extract_iocs(text: str) -> IOCResult:
    """
    Extract IOCs from normalized text.
    """
    normalized_text = refang(text)

    ipv4_regex = r"\b(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\b"
    url_regex = r"\bhttps?://[^\s\"'<>]+"
    email_regex = r"\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b"
    domain_regex = r"\b(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}\b"

    ips = set(re.findall(ipv4_regex, normalized_text))
    urls = set(re.findall(url_regex, normalized_text))
    emails = set(re.findall(email_regex, normalized_text))
    domains = set(re.findall(domain_regex, normalized_text))

    # Remove domains that are part of emails when possible
    email_domains = {email.split("@", 1)[1] for email in emails}
    domains = domains - email_domains

    hashes = extract_hashes(normalized_text)

    return {
        "ips": sorted(ips),
        "urls": sorted(urls),
        "domains": sorted(domains),
        "emails": sorted(emails),
        "md5": sorted(hashes["md5"]),
        "sha1": sorted(hashes["sha1"]),
        "sha256": sorted(hashes["sha256"]),
    }


def export_json(results: IOCResult, output_path: Path) -> None:
    with output_path.open("w", encoding="utf-8") as f:
        json.dump(results, f, indent=4)


def export_csv(results: IOCResult, output_path: Path) -> None:
    with output_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["ioc_type", "value"])

        for ioc_type, values in results.items():
            for value in values:
                writer.writerow([ioc_type, value])


def print_summary(results: IOCResult) -> None:
    print("\nCTI IOC Parser - Extraction Summary")
    print("-" * 40)
    for ioc_type, values in results.items():
        print(f"{ioc_type.upper():10} : {len(values)}")
    print("-" * 40)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Extract and normalize Indicators of Compromise from text files."
    )
    parser.add_argument("input_file", help="Path to the text file to parse")
    parser.add_argument(
        "--json",
        default="outputs/output.json",
        help="Path to export JSON results",
    )
    parser.add_argument(
        "--csv",
        default="outputs/output.csv",
        help="Path to export CSV results",
    )

    args = parser.parse_args()

    input_path = Path(args.input_file)
    json_path = Path(args.json)
    csv_path = Path(args.csv)

    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    json_path.parent.mkdir(parents=True, exist_ok=True)
    csv_path.parent.mkdir(parents=True, exist_ok=True)

    text = input_path.read_text(encoding="utf-8")
    results = extract_iocs(text)

    export_json(results, json_path)
    export_csv(results, csv_path)
    print_summary(results)

    print(f"\nJSON exported to: {json_path}")
    print(f"CSV exported to:  {csv_path}")


if __name__ == "__main__":
    main()
