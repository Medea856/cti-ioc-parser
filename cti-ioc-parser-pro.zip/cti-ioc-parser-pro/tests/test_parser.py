from parser import extract_iocs, refang


def test_refang_url():
    assert refang("hxxps://evil[.]com") == "https://evil.com"


def test_extract_ip():
    results = extract_iocs("Connection to 185[.]220[.]101[.]45 detected")
    assert "185.220.101.45" in results["ips"]


def test_extract_md5():
    md5 = "44d88612fea8a8f36de82e1278abb02f"
    results = extract_iocs(f"Observed hash: {md5}")
    assert md5 in results["md5"]


def test_extract_url():
    results = extract_iocs("Payload hosted at hxxps://evil-domain[.]com/payload.exe")
    assert "https://evil-domain.com/payload.exe" in results["urls"]
