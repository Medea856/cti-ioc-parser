# Usage Guide

## Parse a sample report

```bash
python parser.py samples/ransomware_report.txt
```

## Export to custom paths

```bash
python parser.py samples/phishing_campaign.txt --json outputs/phishing.json --csv outputs/phishing.csv
```

## Run tests

```bash
pytest
```

## Run API

```bash
uvicorn api.main:app --reload
```

Then send a POST request to:

```text
http://127.0.0.1:8000/parse
```

Body:

```json
{
  "text": "Payload found at hxxps://evil[.]com/payload.exe"
}
```

## Run dashboard

```bash
streamlit run dashboard/app.py
```
