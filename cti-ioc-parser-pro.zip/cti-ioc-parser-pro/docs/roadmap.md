# Roadmap

## Short-term improvements

- Add PDF parsing.
- Add IOC deduplication report.
- Add basic ASN enrichment.
- Add WHOIS enrichment.
- Add VirusTotal integration using an environment variable for the API key.

## Mid-term improvements

- Export to STIX 2.1.
- Add MISP integration.
- Add OpenCTI integration.
- Add Sigma rule generation templates.
- Add Splunk lookup export.

## Long-term improvements

- Threat feed correlation.
- Automated report generation.
- Threat actor tagging.
- MITRE ATT&CK mapping.
- Web dashboard with historical analysis.
