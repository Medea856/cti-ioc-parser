# MITRE ATT&CK Context

This project does not perform automatic MITRE ATT&CK attribution.

However, it can support ATT&CK-based workflows by extracting IOCs from:
- phishing reports
- malware reports
- ransomware advisories
- SOC investigations
- threat intelligence feeds

Extracted IOCs can then be used to support:
- threat hunting
- detection engineering
- alert enrichment
- incident response
- campaign tracking

Example mapping workflow:

1. Extract IOCs from a campaign report.
2. Identify the delivery method, payload and C2 behavior.
3. Map observed behaviors to MITRE ATT&CK techniques.
4. Generate hunting queries for the SOC.
5. Feed validated IOCs into SIEM, MISP or OpenCTI.
